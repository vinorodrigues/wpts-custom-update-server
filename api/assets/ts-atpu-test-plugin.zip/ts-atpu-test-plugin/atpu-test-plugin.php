<?php
/**
 * Plugin Name: TS Automatic Theme Plugin Update Tester
 * Plugin URI: http://github.com/vinorodrigues/wp-automatic-theme-plugin-update
 * Description: Not a real theme!  (Just used for testing)
 * Version: 0.01
**/


/*  DO NOTHING  */
/*  DO NOTHING  */
/*  DO NOTHING  */
/*  DO NOTHING  */
/*  DO NOTHING  */


/* eof */
