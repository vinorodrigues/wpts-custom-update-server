<?php

/* updates */

if (function_exists( 'ts_atpu_regsiter_theme' )) :
ts_atpu_regsiter_theme( basename(get_stylesheet_directory_uri()), 'http://localhost/wp' );
endif;

/* eof */
